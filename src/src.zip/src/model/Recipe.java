package model;

public class Recipe {
    private int id;
    private String name;
    private String category;
    private boolean vegetarian;
    private String ingredients;
    private String instructions;
    private String substitutes;

    public Recipe(int id, String name, String category, boolean vegetarian,
                  String ingredients, String instructions, String substitutes) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.vegetarian = vegetarian;
        this.ingredients = ingredients;
        this.instructions = instructions;
        this.substitutes = substitutes;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public boolean isVegetarian() { return vegetarian; }
    public String getIngredients() { return ingredients; }
    public String getInstructions() { return instructions; }
    public String getSubstitutes() { return substitutes; }

    public String[] getIngredientArray() {
        return ingredients.toLowerCase().split(",");
    }

    @Override
    public String toString() {
        return id + ". " + name + " [" + category + ", "
                + (vegetarian ? "Vegetarian" : "Non-Vegetarian") + "]";
    }
}
