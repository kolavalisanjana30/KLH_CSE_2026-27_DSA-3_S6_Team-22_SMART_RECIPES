package data;

import model.Recipe;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class RecipeRepository {
    private Recipe[] recipes;
    private int size;

    public RecipeRepository(int capacity) {
        recipes = new Recipe[capacity];
        size = 0;
    }

    public void add(Recipe recipe) {
        if (size == recipes.length) {
            Recipe[] bigger = new Recipe[recipes.length * 2];
            for (int i = 0; i < recipes.length; i++) {
                bigger[i] = recipes[i];
            }
            recipes = bigger;
        }
        recipes[size++] = recipe;
    }

    public int size() { return size; }

    public Recipe get(int index) {
        if (index < 0 || index >= size) return null;
        return recipes[index];
    }

    public Recipe findById(int id) {
        for (int i = 0; i < size; i++) {
            if (recipes[i].getId() == id) return recipes[i];
        }
        return null;
    }

    public void loadFromFile(String path) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line;
        while ((line = br.readLine()) != null) {
            if (line.trim().length() == 0 || line.startsWith("#")) continue;
            String[] p = line.split("\\|", -1);
            if (p.length < 7) continue;

            int id = Integer.parseInt(p[0].trim());
            String name = p[1].trim();
            String category = p[2].trim();
            boolean vegetarian = p[3].trim().equalsIgnoreCase("V");
            String ingredients = p[4].trim();
            String instructions = p[5].trim();
            String substitutes = p[6].trim();

            add(new Recipe(id, name, category, vegetarian,
                    ingredients, instructions, substitutes));
        }
        br.close();
    }
}
