package algorithms;

public class Levenshtein {

    // Wagner-Fischer dynamic programming.
    // Space optimized to O(min(n,m)).
    public static int distance(String a, String b) {
        if (a == null) a = "";
        if (b == null) b = "";

        a = a.toLowerCase();
        b = b.toLowerCase();

        if (a.length() < b.length()) {
            String temp = a;
            a = b;
            b = temp;
        }

        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];

        for (int j = 0; j <= b.length(); j++) {
            previous[j] = j;
        }

        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;

            for (int j = 1; j <= b.length(); j++) {
                int insert = current[j - 1] + 1;
                int delete = previous[j] + 1;
                int replace = previous[j - 1]
                        + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1);

                current[j] = min(insert, delete, replace);
            }

            int[] temp = previous;
            previous = current;
            current = temp;
        }

        return previous[b.length()];
    }

    public static double similarity(String a, String b) {
        int max = Math.max(a.length(), b.length());
        if (max == 0) return 1.0;
        return 1.0 - ((double) distance(a, b) / max);
    }

    private static int min(int a, int b, int c) {
        int result = a < b ? a : b;
        return result < c ? result : c;
    }
}
