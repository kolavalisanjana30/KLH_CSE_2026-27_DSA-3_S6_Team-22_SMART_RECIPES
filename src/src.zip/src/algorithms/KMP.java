package algorithms;

public class KMP {

    private static String normalize(String s) {
        if (s == null) return "";
        return s.toLowerCase();
    }

    // LPS[i] = length of the longest proper prefix which is also a suffix.
    public static int[] buildLPS(String pattern) {
        pattern = normalize(pattern);
        int[] lps = new int[pattern.length()];
        int len = 0;
        int i = 1;

        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                lps[i] = ++len;
                i++;
            } else if (len > 0) {
                len = lps[len - 1];
            } else {
                lps[i] = 0;
                i++;
            }
        }
        return lps;
    }

    // Returns number of occurrences of pattern in text.
    public static int countMatches(String text, String pattern) {
        text = normalize(text);
        pattern = normalize(pattern);

        if (pattern.length() == 0) return 0;

        int[] lps = buildLPS(pattern);
        int i = 0;
        int j = 0;
        int count = 0;

        while (i < text.length()) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++;
                j++;

                if (j == pattern.length()) {
                    count++;
                    j = lps[j - 1];
                }
            } else if (j > 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
        return count;
    }

    public static boolean contains(String text, String pattern) {
        return countMatches(text, pattern) > 0;
    }
}
