package algorithms;

public class SuffixArray {

    private String text;
    private int[] sa;
    private int[] rank;
    private int[] lcp;

    public SuffixArray(String input) {
        text = input == null ? "" : input;
        buildSuffixArray();
        buildLCP();
    }

    private void buildSuffixArray() {
        int n = text.length();
        sa = new int[n];
        rank = new int[n];

        if (n == 0) return;

        for (int i = 0; i < n; i++) {
            sa[i] = i;
            rank[i] = text.charAt(i);
        }

        int[] tempSA = new int[n];
        int[] tempRank = new int[n];

        // Doubling + hand-built merge sort.
        // Each round sorts suffixes using (rank[i], rank[i+k]).
        // O(n log n) per sorting phase and O(log n) phases:
        // O(n log^2 n) overall.
        for (int k = 1; k < n; k *= 2) {
            mergeSort(sa, tempSA, 0, n - 1, k);

            tempRank[sa[0]] = 0;
            int classes = 1;

            for (int i = 1; i < n; i++) {
                int previous = sa[i - 1];
                int current = sa[i];

                if (compareSuffix(previous, current, k) != 0) {
                    classes++;
                }

                tempRank[current] = classes - 1;
            }

            for (int i = 0; i < n; i++) {
                rank[i] = tempRank[i];
            }

            if (classes == n) break;
        }
    }

    private void mergeSort(int[] array, int[] temp,
                           int left, int right, int k) {
        if (left >= right) return;

        int mid = left + (right - left) / 2;
        mergeSort(array, temp, left, mid, k);
        mergeSort(array, temp, mid + 1, right, k);
        merge(array, temp, left, mid, right, k);
    }

    private void merge(int[] array, int[] temp,
                       int left, int mid, int right, int k) {
        int i = left;
        int j = mid + 1;
        int pos = left;

        while (i <= mid && j <= right) {
            if (compareSuffix(array[i], array[j], k) <= 0) {
                temp[pos++] = array[i++];
            } else {
                temp[pos++] = array[j++];
            }
        }

        while (i <= mid) temp[pos++] = array[i++];
        while (j <= right) temp[pos++] = array[j++];

        for (int x = left; x <= right; x++) {
            array[x] = temp[x];
        }
    }

    private int compareSuffix(int a, int b, int k) {
        if (rank[a] != rank[b]) {
            return rank[a] < rank[b] ? -1 : 1;
        }

        int ra = a + k < text.length() ? rank[a + k] : -1;
        int rb = b + k < text.length() ? rank[b + k] : -1;

        if (ra == rb) return 0;
        return ra < rb ? -1 : 1;
    }

    private void buildLCP() {
        int n = text.length();
        lcp = new int[n];

        if (n == 0) return;

        int[] inverse = new int[n];

        for (int i = 0; i < n; i++) {
            inverse[sa[i]] = i;
        }

        int h = 0;

        // Kasai algorithm: O(n).
        for (int i = 0; i < n; i++) {
            int position = inverse[i];

            if (position == 0) continue;

            int j = sa[position - 1];

            while (i + h < n && j + h < n
                    && text.charAt(i + h) == text.charAt(j + h)) {
                h++;
            }

            lcp[position] = h;

            if (h > 0) h--;
        }
    }

    /*
     * Finds the longest common substring between the suffix-array text
     * and another string by building:
     *
     * first + separator + second
     *
     * and checking LCP values of adjacent suffixes belonging to
     * different documents.
     */
    public int longestCommonSubstring(String other) {
        if (other == null || text.length() == 0 || other.length() == 0) {
            return 0;
        }

        char separator = chooseSeparator(text, other);
        String combined = text + separator + other;

        SuffixArray combinedSA = new SuffixArray(combined);

        int firstEnd = text.length();
        int best = 0;

        for (int i = 1; i < combinedSA.sa.length; i++) {
            int a = combinedSA.sa[i - 1];
            int b = combinedSA.sa[i];

            boolean aInFirst = a < firstEnd;
            boolean bInFirst = b < firstEnd;

            if (aInFirst != bInFirst) {
                int common = combinedSA.lcp[i];

                // Never count characters after the separator.
                int aLimit = aInFirst ? firstEnd - a : combined.length() - a;
                int bLimit = bInFirst ? combined.length() - b : firstEnd - a;

                int separatorIndex = firstEnd;
                if (a < separatorIndex && b < separatorIndex) {
                    common = min(common, separatorIndex - a);
                    common = min(common, separatorIndex - b);
                }

                if (a >= separatorIndex) {
                    common = min(common, combined.length() - a);
                }

                if (b >= separatorIndex) {
                    common = min(common, combined.length() - b);
                }

                if (common > best) best = common;
            }
        }

        return best;
    }

    private char chooseSeparator(String a, String b) {
        char[] candidates = new char[] {
            '\u0000', '\u0001', '\u0002', '\u0003', '\u0004'
        };

        for (int i = 0; i < candidates.length; i++) {
            if (a.indexOf(candidates[i]) == -1
                    && b.indexOf(candidates[i]) == -1) {
                return candidates[i];
            }
        }

        return '\u0000';
    }

    private int min(int a, int b) {
        return a < b ? a : b;
    }

    public int[] getSuffixArray() {
        int[] copy = new int[sa.length];
        for (int i = 0; i < sa.length; i++) copy[i] = sa[i];
        return copy;
    }

    public int[] getLCP() {
        int[] copy = new int[lcp.length];
        for (int i = 0; i < lcp.length; i++) copy[i] = lcp[i];
        return copy;
    }
}
