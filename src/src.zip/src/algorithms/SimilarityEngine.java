package algorithms;

public class SimilarityEngine {

    public static double suffixSimilarity(String a, String b) {
        if (a == null) a = "";
        if (b == null) b = "";

        String x = a.toLowerCase();
        String y = b.toLowerCase();

        int maxLength = Math.max(x.length(), y.length());
        if (maxLength == 0) return 1.0;

        SuffixArray suffixArray = new SuffixArray(x);
        int common = suffixArray.longestCommonSubstring(y);

        return (double) common / maxLength;
    }
}
