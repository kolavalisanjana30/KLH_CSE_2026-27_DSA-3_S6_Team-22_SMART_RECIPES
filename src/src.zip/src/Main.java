import data.RecipeRepository;
import engine.SmartRecipeEngine;
import model.Recipe;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

    private static BufferedReader input =
            new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) {
        RecipeRepository repository = new RecipeRepository(10);

        try {
            repository.loadFromFile("data/recipes.txt");
        } catch (IOException e) {
            System.out.println("Could not load recipe database: " + e.getMessage());
            return;
        }

        SmartRecipeEngine engine = new SmartRecipeEngine(repository);

        System.out.println("==============================================");
        System.out.println("           SMART RECIPES - DSA 3");
        System.out.println("==============================================");
        System.out.println("Loaded recipes: " + repository.size());

        boolean running = true;

        while (running) {
            printMenu();
            int choice = readInt("Enter choice: ");

            switch (choice) {
                case 1:
                    String ingredientInput = readLine(
                            "Enter available ingredients (comma separated): ");
                    engine.ingredientRecommendations(ingredientInput);
                    break;

                case 2:
                    String pattern = readLine("Enter pattern to search: ");
                    engine.patternSearch(pattern);
                    break;

                case 3:
                    String fuzzy = readLine(
                            "Enter recipe/ingredient spelling to search: ");
                    int threshold = readInt("Maximum edit distance (e.g. 2): ");
                    engine.fuzzySearch(fuzzy, threshold);
                    break;

                case 4:
                    showRecipes(repository);
                    break;

                case 5:
                    int id1 = readInt("Enter first recipe ID: ");
                    int id2 = readInt("Enter second recipe ID: ");
                    engine.compareRecipes(id1, id2);
                    break;

                case 6:
                    showRecipe(repository);
                    break;

                case 7:
                    System.out.println("Thank you for using Smart Recipes!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n---------------- MAIN MENU ----------------");
        System.out.println("1. Smart Recipe Recommendation");
        System.out.println("2. Pattern Search (KMP)");
        System.out.println("3. Fuzzy Search (Levenshtein DP)");
        System.out.println("4. List All Recipes");
        System.out.println("5. Compare Two Recipes (Suffix Array)");
        System.out.println("6. View Recipe Details");
        System.out.println("7. Exit");
        System.out.println("-------------------------------------------");
    }

    private static void showRecipes(RecipeRepository repository) {
        System.out.println("\n=== ALL RECIPES ===");
        for (int i = 0; i < repository.size(); i++) {
            System.out.println(repository.get(i));
        }
    }

    private static void showRecipe(RecipeRepository repository) {
        int id = readInt("Enter recipe ID: ");
        Recipe r = repository.findById(id);

        if (r == null) {
            System.out.println("Recipe not found.");
            return;
        }

        System.out.println("\n=== RECIPE DETAILS ===");
        System.out.println("Name: " + r.getName());
        System.out.println("Category: " + r.getCategory());
        System.out.println("Type: " +
                (r.isVegetarian() ? "Vegetarian" : "Non-Vegetarian"));
        System.out.println("Ingredients: " + r.getIngredients());
        System.out.println("Instructions: " + r.getInstructions());
        System.out.println("Possible substitutes: " + r.getSubstitutes());
    }

    private static String readLine(String message) {
        while (true) {
            try {
                System.out.print(message);
                return input.readLine();
            } catch (IOException e) {
                System.out.println("Input error. Try again.");
            }
        }
    }

    private static int readInt(String message) {
        while (true) {
            try {
                String s = readLine(message);
                return Integer.parseInt(s.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
