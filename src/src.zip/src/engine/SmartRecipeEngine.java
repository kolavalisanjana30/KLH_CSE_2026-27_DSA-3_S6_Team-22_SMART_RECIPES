package engine;

import algorithms.KMP;
import algorithms.Levenshtein;
import algorithms.SimilarityEngine;
import data.RecipeRepository;
import model.Recipe;

public class SmartRecipeEngine {

    private RecipeRepository repository;

    public SmartRecipeEngine(RecipeRepository repository) {
        this.repository = repository;
    }

    public void patternSearch(String pattern) {
        System.out.println("\n=== KMP PATTERN SEARCH ===");

        if (pattern == null || pattern.trim().length() == 0) {
            System.out.println("Enter a non-empty pattern.");
            return;
        }

        int found = 0;

        for (int i = 0; i < repository.size(); i++) {
            Recipe r = repository.get(i);
            String searchableText = r.getName() + " " + r.getIngredients();
            int count = KMP.countMatches(searchableText, pattern);

            if (count > 0) {
                System.out.println(r + " -> " + count
                        + " match(es) in recipe name/ingredients");
                found++;
            }
        }

        if (found == 0) {
            System.out.println("No matching recipes found.");
        } else {
            System.out.println("Recipes matched: " + found);
        }
    }

    public void fuzzySearch(String query, int threshold) {
        System.out.println("\n=== FUZZY SEARCH (LEVENSHTEIN DP) ===");

        if (query == null || query.trim().length() == 0) {
            System.out.println("Enter a non-empty ingredient/recipe name.");
            return;
        }

        Recipe[] matches = new Recipe[repository.size()];
        int[] distances = new int[repository.size()];
        int count = 0;

        for (int i = 0; i < repository.size(); i++) {
            Recipe r = repository.get(i);

            int nameDistance = Levenshtein.distance(query, r.getName());
            int best = nameDistance;

            String[] ingredients = r.getIngredientArray();
            for (int j = 0; j < ingredients.length; j++) {
                String ingredient = ingredients[j].trim();
                int d = Levenshtein.distance(query, ingredient);
                if (d < best) best = d;
            }

            if (best <= threshold) {
                matches[count] = r;
                distances[count] = best;
                count++;
            }
        }

        // Hand-built selection sort: smallest edit distance first.
        for (int i = 0; i < count - 1; i++) {
            int bestIndex = i;

            for (int j = i + 1; j < count; j++) {
                if (distances[j] < distances[bestIndex]) {
                    bestIndex = j;
                }
            }

            if (bestIndex != i) {
                int tempD = distances[i];
                distances[i] = distances[bestIndex];
                distances[bestIndex] = tempD;

                Recipe tempR = matches[i];
                matches[i] = matches[bestIndex];
                matches[bestIndex] = tempR;
            }
        }

        if (count == 0) {
            System.out.println("No fuzzy matches within edit distance " + threshold + ".");
            return;
        }

        for (int i = 0; i < count; i++) {
            System.out.println(matches[i] + " -> edit distance = " + distances[i]);
        }
    }

    public void ingredientRecommendations(String ingredientInput) {
        System.out.println("\n=== SMART RECIPE RECOMMENDATION ===");

        if (ingredientInput == null || ingredientInput.trim().length() == 0) {
            System.out.println("Enter at least one ingredient.");
            return;
        }

        String[] input = ingredientInput.toLowerCase().split(",");
        Recipe[] results = new Recipe[repository.size()];
        int[] scores = new int[repository.size()];
        int count = 0;

        for (int i = 0; i < repository.size(); i++) {
            Recipe r = repository.get(i);
            String[] recipeIngredients = r.getIngredientArray();
            int score = 0;

            for (int a = 0; a < input.length; a++) {
                String wanted = input[a].trim();

                for (int b = 0; b < recipeIngredients.length; b++) {
                    String available = recipeIngredients[b].trim();

                    if (KMP.contains(available, wanted)
                            || KMP.contains(wanted, available)) {
                        score++;
                        break;
                    }
                }
            }

            if (score > 0) {
                results[count] = r;
                scores[count] = score;
                count++;
            }
        }

        // Selection sort by number of matching ingredients.
        for (int i = 0; i < count - 1; i++) {
            int best = i;

            for (int j = i + 1; j < count; j++) {
                if (scores[j] > scores[best]) {
                    best = j;
                }
            }

            if (best != i) {
                int temp = scores[i];
                scores[i] = scores[best];
                scores[best] = temp;

                Recipe tempR = results[i];
                results[i] = results[best];
                results[best] = tempR;
            }
        }

        if (count == 0) {
            System.out.println("No recipes matched your ingredients.");
            return;
        }

        for (int i = 0; i < count; i++) {
            System.out.println((i + 1) + ". " + results[i].getName()
                    + " -> " + scores[i] + " matching ingredient(s)");
        }
    }

    public void compareRecipes(int id1, int id2) {
        System.out.println("\n=== SUFFIX-BASED DOCUMENT SIMILARITY ===");

        Recipe a = repository.findById(id1);
        Recipe b = repository.findById(id2);

        if (a == null || b == null) {
            System.out.println("Invalid recipe ID.");
            return;
        }

        String docA = a.getName() + " " + a.getIngredients()
                + " " + a.getInstructions();
        String docB = b.getName() + " " + b.getIngredients()
                + " " + b.getInstructions();

        double score = SimilarityEngine.suffixSimilarity(docA, docB);

        System.out.println(a.getName() + " vs " + b.getName());
        System.out.println("Longest common substring based similarity: "
                + format(score * 100) + "%");
        System.out.println("(This is structural text similarity, not semantic similarity.)");
    }

    private String format(double value) {
        long rounded = Math.round(value * 100.0);
        return (rounded / 100) + "." + twoDigits(rounded % 100);
    }

    private String twoDigits(long value) {
        if (value < 10) return "0" + value;
        return "" + value;
    }
}
